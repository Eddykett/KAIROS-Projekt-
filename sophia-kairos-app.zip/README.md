# SOPHIA/KAIROS App

Initiales Grundgerüst für die Smartphone-App zur Interaktion mit KAIROS.

## Struktur
- frontend: React + Tailwind UI
- backend: FastAPI API
- shared: Gemeinsame Module

## Start
- Frontend: `npm install` + `npm start`
- Backend: `uvicorn backend.main:app --reload`
